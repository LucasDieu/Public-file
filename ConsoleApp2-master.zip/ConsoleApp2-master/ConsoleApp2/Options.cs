﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
     enum Options
    {
        Customer=1,
        Visitor
    }
}
