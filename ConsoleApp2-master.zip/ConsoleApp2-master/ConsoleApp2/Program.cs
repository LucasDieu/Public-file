﻿using System;
namespace ConsoleApp2
{
    class Program{
        public static void Main() {
           
            Dashboard dashboard = new Dashboard();
            dashboard.Run();
        }
    }
}